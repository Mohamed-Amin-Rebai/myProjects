
//  TP1
// definition d'une fonction somme

function somme(n) {
  let sum = 0;
  for (let i = 1; i <= n; i++) {
    sum += i;
    // create a new element with the results and append it to the HTML
    const resultElement = document.createElement("p");
    resultElement.innerHTML = `Pour i = ${i} ---> somme = ${sum}`;
    document.getElementById("results").appendChild(resultElement);
  }
  return sum;
}

function game1() {
  const nombre = prompt("Somme jusqu'a ?", 10);
  // check if the user entered valid input
  if (nombre === null || isNaN(nombre)) {
    alert("Veuillez entrer un nombre valide !");
    return;
  }
  const sum = somme(parseInt(nombre));
  const sumElement = document.createElement("p");
  sumElement.innerHTML = `Somme = ${sum}`;
  document.getElementById("results").appendChild(sumElement);
}

//  TP2
function moyenne() {
  var n1 = parseInt(document.f1.n1.value);
  var n2 = parseInt(document.f1.n2.value);
  var n3 = parseInt(document.f1.n3.value);
  var moy = (n1 + n2 + n3) / 3;
  document.getElementById("result").innerHTML = "La moyenne est : " + moy;
}

//  TP3
function displayTable() {
  let n = parseInt(document.getElementById("inputNumber").value);
  let table = "";
  for (let i = 1; i <= 9; i++) {
    table += `<div>${n} * ${i} = ${n * i}</div>`;
  }
  document.getElementById("resultDiv").innerHTML = table;
}


// TP4
    function nb_aleatoire(min, max) {
      var nb = min + Math.floor((max - min + 1) * Math.random());
      return nb;
    }

    function jouer() {
      var min = parseInt(prompt("Entrez le nombre minimum de l'intervalle :"));
      var max = parseInt(prompt("Entrez le nombre maximum de l'intervalle :"));

      var nombreADeviner = nb_aleatoire(min, max);
      var nombreDeCoups = 0;

      while (true) {
          var proposition = parseInt(prompt("Devinez le nombre entre " + min + " et " + max + " :"));
          nombreDeCoups++;

          if (proposition === nombreADeviner) {
              alert("Bravo, vous avez trouvé le nombre en " + nombreDeCoups + " coups !");
              return nombreDeCoups;
          } else if (proposition < nombreADeviner) {
              alert("Le nombre à deviner est plus grand que " + proposition + ".");
          } else {
              alert("Le nombre à deviner est plus petit que " + proposition + ".");
          }
      }
    }

    function serie() {
      var meilleurScore = Infinity;
      var nbParties = 0;
      var scoreTotal = 0;

      while (true) {
          var score = jouer();
          if (score < meilleurScore) {
              meilleurScore = score;
          }

          nbParties++;
          scoreTotal += score;

          var choix = prompt("Voulez-vous continuer la série de parties ? (o/n)");
          if (choix.toLowerCase() !== "o") {
              break;
          }
      }

      alert("Vous avez joué " + nbParties + " parties avec un score moyen de " + (scoreTotal / nbParties) + " coups par partie.");
      alert("Votre meilleur score dans cette série de parties est " + meilleurScore + " coups.");
    }
                





// tp5
// function createForm1() {
// 	var form = document.createElement("form");
// 	form.id = "form1";
// 	var label = document.createElement("label");
// 	label.setAttribute("for", "zoneSaisie");
// 	label.textContent = "Saisissez une valeur :";
// 	form.appendChild(label);
// 	var input = document.createElement("input");
// 	input.type = "number";
// 	input.id = "zoneSaisie";
// 	input.name = "valeur";
// 	input.value = "5";
// 	form.appendChild(input);
// 	var button = document.createElement("button");
// 	button.type = "button";
// 	button.textContent = "Valider";
// 	button.addEventListener("click", function() {
// 		form.action = "resultat.html";
// 		form.submit();
// 	});
//     form.appendChild(button);
// 	document.body.appendChild(form);
// }

// function createForm2() {
// 	var form = document.createElement("form");
// 	form.id = "form2";
// 	var label = document.createElement("label");
// 	label.setAttribute("for", "choixUnique");
// 	label.textContent = "Choisissez une valeur :";
// 	form.appendChild(label);
// 	for (var i = 1; i <= 5; i++) {
// 		var input = document.createElement("input");
// 		input.type = "radio";
// 		input.id = "choix" + i;
// 		input.name = "choix";
// 		input.value = i.toString();
// 		form.appendChild(input);
// 		var label = document.createElement("label");
// 		label.setAttribute("for", "choix" + i);
// 		label.textContent = i.toString();
//         form.appendChild(label);
// 		form.appendChild(document.createElement("br"));
// 	}
// 	var button = document.createElement("button");
// 	button.type = "button";
// 	button.textContent = "Valider";
// 	button.addEventListener("click", function() {
// 		form.action = "resultat.html";
// 		form.submit();
// 	});
// 	form.appendChild(button);
// 	document.body.appendChild(form);
// }

// function createForm3() {
// 	var form = document.createElement("form");
// 	form.id = "form3";
// 	var label = document.createElement("label");
// 	label.setAttribute("for", "menuDeroulant");
// 	label.textContent = "Choisissez une valeur :";
// 	form.appendChild(label);
//     var select = document.createElement("select");
// 	select.id = "menuDeroulant";
// 	select.name = "choix";
// 	for (var i = 1; i <= 5; i++) {
// 		var option = document.createElement("option");
// 		option.value = i.toString();
// 		option.textContent = i.toString();
// 		select.appendChild(option);
// 	}
// 	form.appendChild(select);
// 	var button = document.createElement("button");
// 	button.type = "button";
// 	button.textContent = "Valider";
// 	button.addEventListener("click", function() {
// 		form.action = "resultat.html";
// 		form.submit();
// 	});
// 	form.appendChild(button);
// 	document.body.appendChild(form);
// }
// window.onload = function() {
// 	createForm1();
// 	createForm2();
// 	createForm3();
// };
