//
// Ce fichier a été généré par Eclipse Implementation of JAXB, v4.0.5 
// Voir https://eclipse-ee4j.github.io/jaxb-ri 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
//

@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://example.com/reservation", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.mycompany.app.event_organization.entity;
